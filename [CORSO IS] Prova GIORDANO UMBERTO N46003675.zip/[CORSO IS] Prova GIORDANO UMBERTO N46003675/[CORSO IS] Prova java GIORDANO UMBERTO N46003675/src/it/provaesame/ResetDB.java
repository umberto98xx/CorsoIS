package it.provaesame;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import Db.*;

public class ResetDB 
{
	public static void main(String[] args) 
	{
		Connection conn = DBManager.getConnection();
		
		ArrayList<String> sqlqueries = new ArrayList<String>();
		
		sqlqueries.add(
					   "drop table elaborato;\n" + 
							   "drop table elaboratiAssegnati;\n" +
					   "drop table docente;\n");
		try 
		{
			for(String query : sqlqueries) 
			{
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.executeUpdate();
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}	
	}
}