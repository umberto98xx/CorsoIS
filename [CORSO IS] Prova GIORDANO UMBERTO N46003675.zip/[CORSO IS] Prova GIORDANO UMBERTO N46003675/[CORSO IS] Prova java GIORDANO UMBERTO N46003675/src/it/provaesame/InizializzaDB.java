package it.provaesame;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import Db.DBManager;

public class InizializzaDB {

	public static void main(String[] args) {

		Connection conn = DBManager.getConnection();
		
		ArrayList<String> sqlqueries = new ArrayList<String>();
		
		sqlqueries.add("CREATE TABLE Docente( \n" + 
				"  Nome VARCHAR(30),\n" +
				"  Cognome VARCHAR(30),\n" +
				"  CodiceInsegnamento INT,\n" +
				"  NElaborati INT,\n" + 
				"  PRIMARY KEY(CodiceInsegnamento)\n" + 
				");");
		
		sqlqueries.add("CREATE TABLE Elaborato( \n" + 
				"  Nome VARCHAR(30),\n" +
				"  Docente INT,\n" +
				"  Tematica VARCHAR(30),\n" + 
				"  Assegnazione BOOLEAN,\n" +
				"  FOREIGN KEY(Docente) REFERENCES Docente(CodiceInsegnamento),\n" +
				"  PRIMARY KEY(Nome)\n" + 
				");");
		
		sqlqueries.add("CREATE TABLE ElaboratiAssegnati( \n" + 
				"  id INT,\n" +
				"  Matricola VARCHAR(30),\n" + 
				"  CFU INT,\n" +
				"  NomeElaborato VARCHAR(30),\n" + 
				"  CodiceInsegnamento INT,\n" +
				"  PRIMARY KEY(id)\n" + 
				");");
		
		
		try {
			for(String query : sqlqueries) {
				PreparedStatement stmt = conn.prepareStatement(query);
				stmt.executeUpdate();
			}
		}
		catch(SQLException e) {

			e.printStackTrace();
		}	
		

		
	}

}