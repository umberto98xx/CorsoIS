package it.provaesame;

import control.*;
import Entity.*;

import java.sql.SQLException;

import Db.*;

public class Main {

	
	public static void main(String[] args) throws DAOException {
		GestioneElaborati gestioneelaborati=null;
		
		try {
			gestioneelaborati = new GestioneElaborati();
			// inizio parte per aggiunta di elaborati e docenti nel sistema			
			Docente doc1=new Docente("Luigi","Verolino",11);
			gestioneelaborati.addDocente(doc1);
			
			Docente doc2=new Docente("Antonio","Banderas",12);
			gestioneelaborati.addDocente(doc2);

			
			Elaborato e1=new Elaborato("Impianti",doc1,Tematica.COMPILATIVA,true);
			gestioneelaborati.addElaborato(e1);
			
			Elaborato e2=new Elaborato("Programmazione",doc2,Tematica.COMPILATIVA,false);
			gestioneelaborati.addElaborato(e2);
			
			Elaborato e3=new Elaborato("Elettrotecnica",doc1,Tematica.COMPILATIVA,true);
			gestioneelaborati.addElaborato(e3);
			
			Elaborato e4=new Elaborato("Software",doc2,Tematica.PROGETTUALE,false);
			gestioneelaborati.addElaborato(e4);
			
			//qui inizia la simulazione di uno studente che chiede al sistema di assegnargli un elaborato
			String matricola = "N4603675";
			int CFU=170;
			String pref1="Impianti";
			String pref2="Programmazione";
			String pref3="Elettrotecnica";
			
			Studente studente=new Studente(matricola,CFU,pref1,pref2,pref3);
			
			Elaborato elab1=gestioneelaborati.createObjectElaborato(pref1);
			Elaborato elab2=gestioneelaborati.createObjectElaborato(pref2);
			Elaborato elab3=gestioneelaborati.createObjectElaborato(pref3);
			
			RichiestaAssegnazione R1=new RichiestaAssegnazione(1,studente,elab1,elab2,elab3);
			Elaborato risultato;
			try {
				risultato = gestioneelaborati.AnalisiAssegnazione(R1);
				ElaboratiAssegnati EA=new ElaboratiAssegnati(1,matricola,CFU,risultato.getnome(),risultato.getdocente().getcodiceInsegnamento());
				gestioneelaborati.addElaboratiAssegnati(EA);
			
				System.out.println("L'elaborato assegnato allo studente " + EA.getmatricola()+" avente N CFU " +
				EA.getCFU() + " � " + EA.getnomeelaborato() + " del docente con codice insegnamento " + EA.getcodiceinsegnamento());

				
				
			} catch (richiestaException e) {
				System.out.println(e.getMessage());
			}
			
			
			
			
		} catch (DAOException e) {		
			
			System.out.println("Errore accesso DB");

			e.printStackTrace();
		
			System.exit(1);
		
		

	}

}
}