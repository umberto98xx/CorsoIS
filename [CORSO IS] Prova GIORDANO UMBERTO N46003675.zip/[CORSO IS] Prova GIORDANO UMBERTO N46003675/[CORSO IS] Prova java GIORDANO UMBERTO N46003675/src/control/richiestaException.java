package control;

public class richiestaException extends Exception {

	public richiestaException() {
		// TODO Auto-generated constructor stub
	}

	public richiestaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public richiestaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public richiestaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public richiestaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
