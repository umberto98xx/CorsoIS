package control;

import Db.*;
import Entity.*;
import java.util.*;


public class GestioneElaborati{
	
	public ArrayList<Elaborato> elaboratilist = new ArrayList<Elaborato>();
	public ArrayList<Docente> docentilist = new ArrayList<Docente>();
	public ArrayList<ElaboratiAssegnati> elaboratiassegnatilist = new ArrayList<ElaboratiAssegnati>();
	
	public GestioneElaborati() throws DAOException 
	{
		elaboratilist = ElaboratoDAO.readAll();
		docentilist = DocenteDAO.readAll();
		elaboratiassegnatilist=ElaboratiAssegnatiDAO.readAll();
	}
	
	public ArrayList<Elaborato> getElaborati() throws DAOException
	{
		return elaboratilist;
	}

	public void setElaborati(ArrayList<Elaborato> elaboratilist) throws DAOException
	{
		this.elaboratilist = elaboratilist;	
	}
	
	public ArrayList<ElaboratiAssegnati> getElaboratiAssegnati() throws DAOException
	{
		return elaboratiassegnatilist;
	}

	public void setElaboratiAssegnati(ArrayList<ElaboratiAssegnati> elaboratiassegnatilist) throws DAOException
	{
		this.elaboratiassegnatilist = elaboratiassegnatilist;	
	}
	
	public ArrayList<Docente> getDocenti() throws DAOException
	{
		return docentilist;
	}

	public void setDocenti(ArrayList<Docente> docentilist) throws DAOException
	{
		this.docentilist = docentilist;
		
	}
	
	public void addElaborato(Elaborato el) throws DAOException 
	{
		elaboratilist.add(el);
		
		Elaborato elaborato = ElaboratoDAO.create(el);
	}
	
	public void addDocente(Docente d) throws DAOException
	{	
		docentilist.add(d);
		Docente docente = DocenteDAO.create(d);
	}
	
	public void addElaboratiAssegnati(ElaboratiAssegnati el) throws DAOException 
	{
		elaboratiassegnatilist.add(el);
		
		ElaboratiAssegnati elaborato = ElaboratiAssegnatiDAO.create(el);
	}
	
	
	public Elaborato createObjectElaborato(String pref) throws DAOException{
			
		Elaborato risultato = new Elaborato(null,null,null);
		
		
		for(Elaborato e : elaboratilist) {
			
			if( (e.getnome().equals(pref))){
		
				risultato=e;
			}
		}
		return risultato;
	}
	
	public Elaborato AnalisiAssegnazione(RichiestaAssegnazione R) throws DAOException, richiestaException {
		int CFU=R.studente.CFU;
		Elaborato risultato=new Elaborato(null,null,null);
		if(CFU>130 && CFU<180) {
			
				if(R.getpref1().getassegnazione()==false && R.getpref1().getdocente().NElaborati<10) {
					risultato=R.getpref1();
					risultato.setassegnazione(true);
					ElaboratoDAO.update(risultato);
					DocenteDAO.update(R.getpref1().getdocente());
					
					
				}
				else {
					if(R.getpref2().getassegnazione()==false && R.getpref2().getdocente().NElaborati<10) {
						risultato=R.getpref2();
						risultato.setassegnazione(true);
						ElaboratoDAO.update(risultato);
						DocenteDAO.update(R.getpref1().getdocente());
					}
					else{
						
						if(R.getpref3().getassegnazione()==false && R.getpref3().getdocente().NElaborati<10) {
							risultato=R.getpref3();
							risultato.setassegnazione(true);
							ElaboratoDAO.update(risultato);
							DocenteDAO.update(R.getpref1().getdocente());
						}
						else {
							for(Elaborato e : elaboratilist) {
								
								if((e.getassegnazione()==false) && e.getdocente().NElaborati<10){
									risultato=e;
									risultato.setassegnazione(true);
									ElaboratoDAO.update(risultato);
									DocenteDAO.update(R.getpref1().getdocente());
									return risultato;
								}
								else {
									throw new richiestaException("Non sono disponibili elaborati da scegliere");
									
								}
							}	
						}						
					}
				}
		}
		else if (CFU<0 || CFU>180) {
			throw new richiestaException("Numero di CFU non consentito");
		}
		else{

			throw new richiestaException("Non puoi fare richiesta di un elaborato in quanto il numero di CFU non � sufficente");
		}

		return risultato;
}
}

