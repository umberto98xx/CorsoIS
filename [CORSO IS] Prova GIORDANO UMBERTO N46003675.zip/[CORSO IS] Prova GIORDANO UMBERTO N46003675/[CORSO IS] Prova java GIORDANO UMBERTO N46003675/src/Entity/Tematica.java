package Entity;

public enum Tematica {
	COMPILATIVA,
	PROGETTUALE
}
