package Entity;

public class RichiestaAssegnazione {
	
	public int id;
	public Studente studente;
	public Elaborato pref1;
	public Elaborato pref2;
	public Elaborato pref3;
	
	public RichiestaAssegnazione(int id, Studente studente,Elaborato pref1,Elaborato pref2,Elaborato pref3) {
		this.id=id;
		this.studente=studente;
		this.pref1=pref1;
		this.pref2=pref2;
		this.pref3=pref3;
		
	}
	
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id=id;
		}
	
	public Studente getstudente() {
		return studente;
		}
	public void setstudente(Studente studente) {
		this.studente=studente;
	}		
		public Elaborato getpref2() {
			return pref2;
		}
		
		public void setpref2(Elaborato pref2) {
			this.pref2=pref2;
		}
		
		public Elaborato getpref3() {
			return pref3;
		}
		
		
		public void setpref3(Elaborato pref3) {
			this.pref3=pref3;
		}
		public Elaborato getpref1() {
			return pref1;
		}
		
		public void setpref1(Elaborato pref1) {
			this.pref1=pref1;
		}

	}
	