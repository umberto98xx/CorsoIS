package Entity;

public class ElaboratiAssegnati {
	public int id;
	public String matricola;
	public int CFU;
	public String nomeelaborato;
	public int codiceinsegnamento;
	
	public ElaboratiAssegnati(int id, String matricola,int CFU,String nomeelaborato,int codiceinsegnamento) {
		this.id=id;
		this.matricola=matricola;
		this.CFU=CFU;
		this.nomeelaborato=nomeelaborato;
		this.codiceinsegnamento=codiceinsegnamento;
	}
	
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id=id;
		}
	
	public String getmatricola() {
		return matricola;
		}
	public void setmatricola(String matricola) {
		this.matricola=matricola;
	}		
	
	public int getCFU() {
		return CFU;
	}
	public void setCFU(int CFU) {
		this.CFU=CFU;
		}
	
	public String getnomeelaborato() {
		return nomeelaborato;
		}
	public void setnomeelaborato(String nomeelaborato) {
		this.nomeelaborato=nomeelaborato;
	}	
	public int getcodiceinsegnamento() {
		return codiceinsegnamento;
	}
	public void setcodiceinsegnamento(int codiceinsegnamento) {
		this.codiceinsegnamento=codiceinsegnamento;
		}
		
}
