package Entity;

import Db.DAOException;
import Db.ElaboratoDAO;

public class Docente {
			
			public String nome;
			public String cognome;
			private int codiceInsegnamento;
			public int NElaborati=0;
			
			
				public Docente(String nome, String cognome,int codiceInsegnamento) {
					this.nome=nome;
					this.cognome=cognome;
					this.codiceInsegnamento=codiceInsegnamento;
				}
				
				public Docente(String nome, String cognome,int codiceInsegnamento,int NElaborati) {
					this.nome=nome;
					this.cognome=cognome;
					this.codiceInsegnamento=codiceInsegnamento;
					this.NElaborati=NElaborati;
				}
				
				public String getnome() {
					return new String(nome);
				}
				
				public void setnome(String nome) {
					this.nome=nome;
				}
				
				public String getcognome() {
					return new String(cognome);
				}
				
				public void setcognome(String cognome) {
					this.cognome=cognome;
				}
				
				public int getcodiceInsegnamento() {
					return codiceInsegnamento;
				}
				
				public void setcodiceInsegnamento(int codiceInsegnamento) {
					this.codiceInsegnamento=codiceInsegnamento;
				}
				
				public int getNElaborati() {
					return NElaborati;
				}
				
				public void getNElaborati(int NElaborati) {
					this.NElaborati=NElaborati;
				}
				
				
				
}