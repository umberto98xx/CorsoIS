package Entity;

public class Elaborato {
	public String nome;
	public Docente docente;
	public Tematica tematica;
	public boolean assegnazione;
	
	public Elaborato(String nome,Docente docente, Tematica tematica) {
		this.nome=nome;
		this.docente=docente;
		this.tematica=tematica;
		boolean assegnazione=false;
		
	}
	
	public Elaborato(String nome,Docente docente, Tematica tematica,boolean assegnazione) {
		this.nome=nome;
		this.docente=docente;
		this.tematica=tematica;
		this.assegnazione=assegnazione;
		
		
	}
	
	public String getnome() {
		return new String(nome);
	}
	
	public void setnome(String nome) {
		this.nome=nome;
	}
	
	public Docente getdocente() {
		return docente;
	}
	
	public void setdocente(Docente docente) {
		this.docente=docente;
					
	}
	
	public Tematica gettematica() {
		return tematica;
	}
	
	public void settematica(Tematica tematica) {
		this.tematica=tematica;
					
	}
	
	public boolean getassegnazione() {
		return assegnazione;
	}
	public void setassegnazione(boolean assegnazione) {
		this.assegnazione=assegnazione;
	}
	

}
