package Entity;

public class Studente {
		public String matricola;
		public int CFU;
		public String pref1;
		public String pref2;
		public String pref3;
		
		public Studente(String matricola, int CFU,String pref1,String pref2,String pref3) {
			this.matricola=matricola;
			this.CFU=CFU;
			this.pref1=pref1;
			this.pref2=pref2;
			this.pref3=pref3;
		}
		public String getmatricola() {
			return new String(matricola);
		}
		
		public void setmatricola(String matricola) {
			this.matricola=matricola;
		}
		
		public int getCFU() {
			return CFU;
		}
		
		public void setCFU(int CFU) {
			this.CFU=CFU;
		}
		public String getpref2() {
			return pref2;
		}
		
		public void setpref2(String pref2) {
			this.pref2=pref2;
		}
		
		public String getpref3() {
			return pref3;
		}
		
		public void setpref3(String pref3) {
			this.pref3=pref3;
		}
		public String getpref1() {
			return pref1;
		}
		
		public void setpref1(String pref1) {
			this.pref1=pref1;
		}

}
