package Db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;

import Entity.*;

public class ElaboratiAssegnatiDAO
{
	public static ElaboratiAssegnati create(ElaboratiAssegnati elab) throws DAOException 
	{

		Connection conn = DBManager.getConnection();

		String query = "INSERT INTO ElaboratiAssegnati VALUES (?,?,?,?,?);";
		
		try( PreparedStatement stmt = conn.prepareStatement(query); )
		{
			stmt.setInt(1, elab.getid());
			stmt.setString(2, elab.getmatricola());
			stmt.setInt(3, elab.getCFU());
			stmt.setString(4, elab.getnomeelaborato());
			stmt.setInt(5, elab.getcodiceinsegnamento());
			
			stmt.executeUpdate();
		}
		
		catch(SQLException e) 
		{
			
			throw new DAOException("Errore INSERT ElaboratiAssegnati");
		}
		
		return elab;
	}
	
public static ElaboratiAssegnati read(String matricola) throws DAOException {
		
		ElaboratiAssegnati elaborati = null;
		
		Connection conn = DBManager.getConnection();
		
		String sqlquery = "SELECT id,CFU,NomeElaborato,CodiceInsegnamento FROM ElaboratiAssegnati WHERE Matricola=?";
		
		try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
		{
			
			stmt.setString(1,matricola.toString());

			try( ResultSet result = stmt.executeQuery(); )   
			{
				while (result.next()) {
	        	
					int id=result.getInt(1);
					int CFU=result.getInt(2);
					String nomeelaborato =result.getString(3);
					int codiceinsegnamento=result.getInt(4);
										
					elaborati = new ElaboratiAssegnati(id,matricola,CFU,nomeelaborato,codiceinsegnamento);
				}
			}
		}
		catch(SQLException e) {

			throw new DAOException("Errore SELECT ElaboratiAssegnati");
		}
		
		return elaborati;
	}


public static ArrayList<ElaboratiAssegnati> readAll() throws DAOException {

ArrayList<ElaboratiAssegnati> elaboratilist = new ArrayList<ElaboratiAssegnati>();

Connection conn = DBManager.getConnection();

String sqlquery = "SELECT id,Matricola,CFU,NomeElaborato,CodiceInsegnamento FROM ElaboratiAssegnati";

try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{

	try( ResultSet result = stmt.executeQuery(); )
	{
		while (result.next()) {
    	
			int id=result.getInt(1);
			String matricola =result.getString(2);
			int CFU=result.getInt(3);
			String nomeelaborato =result.getString(4);
			int codiceinsegnamento=result.getInt(5);
								
			ElaboratiAssegnati elaborati = new ElaboratiAssegnati(id,matricola,CFU,nomeelaborato,codiceinsegnamento);
			elaboratilist.add(elaborati);
			
		}
	}
}
catch(SQLException e) {

	throw new DAOException("Errore SELECT ElaboratiAssegnati");
}

return elaboratilist;
}
public static void update(ElaboratiAssegnati elaborati) throws DAOException {

	int id=elaborati.getid();
	String matricola =elaborati.getmatricola();
	int CFU=elaborati.getCFU();
	String nomeelaborato =elaborati.getnomeelaborato();
	int codiceinsegnamento=elaborati.getcodiceinsegnamento();

Connection conn = DBManager.getConnection();

String sqlquery = "UPDATE ElaboratiAssegnati SET Matricola=?, CFU=?, NomeElaborato=?,CodiceInsegnamento=? WHERE id=?;";

try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{
	stmt.setInt(1, id);
	stmt.setString(2, matricola);
	stmt.setInt(3, CFU);
	stmt.setString(4, nomeelaborato);
	stmt.setInt(5, codiceinsegnamento);
	
	stmt.executeUpdate();
}
catch(SQLException e) {

	throw new DAOException("Errore UPDATE ElaboratiAssegnati");
}
}

public static void delete(ElaboratiAssegnati elaborati) throws DAOException {

int id=elaborati.getid();

Connection conn = DBManager.getConnection();

String sqlquery = "DELETE FROM ElaboratiAssegnati WHERE id=?;";

try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{
	stmt.setInt(1, id);
	
	stmt.executeUpdate();
}
catch(SQLException e) {

	throw new DAOException("Errore DELETE ElaboratiAssegnati");
}
}

}
