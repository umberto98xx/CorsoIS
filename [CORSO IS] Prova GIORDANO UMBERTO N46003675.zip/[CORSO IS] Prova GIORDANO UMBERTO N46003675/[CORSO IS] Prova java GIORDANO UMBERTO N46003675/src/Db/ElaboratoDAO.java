package Db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;

import Entity.*;

public class ElaboratoDAO
{
	public static Elaborato create(Elaborato el) throws DAOException 
	{

		Connection conn = DBManager.getConnection();

		String query = "INSERT INTO Elaborato VALUES (?,?,?,?);";
		
		try( PreparedStatement stmt = conn.prepareStatement(query); )
		{
			stmt.setString(1, el.getnome());
			stmt.setInt(2, el.getdocente().getcodiceInsegnamento());
			stmt.setString(3, el.gettematica().toString());
			stmt.setBoolean(4, el.getassegnazione());
			
			stmt.executeUpdate();
		}
		
		catch(SQLException e) 
		{
			
			throw new DAOException("Errore INSERT Elaborato");
		}
		
		return el;
	}
	
public static Elaborato read(String nome) throws DAOException {
		
		Elaborato elaborato = null;
		
		Connection conn = DBManager.getConnection();
		
		String sqlquery = "SELECT Docente,Tematica,Assegnazione FROM Elaborato WHERE Nome=?";
		
		try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
		{
			
			stmt.setString(1, nome.toString());

			try( ResultSet result = stmt.executeQuery(); )   
			{
				while (result.next()) {
	        	
					Docente docente =DocenteDAO.read(result.getInt(1));
					Tematica tematica = Tematica.valueOf( result.getString(2));
					boolean assegnazione=result.getBoolean(3);
										
					elaborato = new Elaborato(nome, docente,tematica,assegnazione);
				}
			}
		}
		catch(SQLException e) {

			throw new DAOException("Errore SELECT Elaborato");
		}
		
		return elaborato;
	}


public static ArrayList<Elaborato> readAll() throws DAOException {

ArrayList<Elaborato> elaboratilist = new ArrayList<Elaborato>();

Connection conn = DBManager.getConnection();

String sqlquery = "SELECT Nome,Docente,Tematica,Assegnazione FROM Elaborato";

try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{

	try( ResultSet result = stmt.executeQuery(); )
	{
		while (result.next()) {
    	
			String nome=result.getString(1);
			Docente docente =DocenteDAO.read(result.getInt(2));
			Tematica tematica = Tematica.valueOf( result.getString(3));
			boolean assegnazione=result.getBoolean(4);
								
			Elaborato elaborato = new Elaborato(nome, docente,tematica,assegnazione);
			elaboratilist.add(elaborato);
			
		}
	}
}
catch(SQLException e) {

	throw new DAOException("Errore SELECT Elaborato");
}

return elaboratilist;
}
public static void update(Elaborato elaborato) throws DAOException {

String nome=elaborato.getnome();
Docente docente=elaborato.getdocente();
Tematica tematica=elaborato.gettematica();
boolean assegnazione=elaborato.getassegnazione();

Connection conn = DBManager.getConnection();

String sqlquery = "UPDATE Elaborato SET Docente=?, Tematica=?, Assegnazione=? WHERE Nome=?;";

try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{
	stmt.setString(4, nome.toString());
	stmt.setInt(1,docente.getcodiceInsegnamento());
	stmt.setString(2,tematica.toString());
	stmt.setBoolean(3, assegnazione);
	
	stmt.executeUpdate();
}
catch(SQLException e) {

	throw new DAOException("Errore UPDATE Elaborato");
}
}

public static void delete(Elaborato elaborato) throws DAOException {

String nome=elaborato.getnome();

Connection conn = DBManager.getConnection();

String sqlquery = "DELETE FROM Elaborato WHERE Nome=?;";

try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
{
	stmt.setString(1, nome.toString());
	
	stmt.executeUpdate();
}
catch(SQLException e) {

	throw new DAOException("Errore DELETE Elaborato");
}
}

}
