package Db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;

import Entity.*;


public class DocenteDAO {
	public static Docente create(Docente docente) throws DAOException 
	{
				
		Connection conn = DBManager.getConnection();

		String query = "INSERT INTO Docente VALUES(?,?,?,?);";
		
		try( PreparedStatement stmt = conn.prepareStatement(query);)
		{
			
			stmt.setString(1, docente.getnome());
			stmt.setString(2, docente.getcognome());
			stmt.setInt(3, docente.getcodiceInsegnamento());
			stmt.setInt(4,docente.getNElaborati());
			
			stmt.executeUpdate();
		}
		
		catch(SQLException e) 
		{
			
			throw new DAOException("Errore INSERT Docente");
		}
		
		return docente;
	}
	
public static Docente read(int codiceinsegnamento) throws DAOException {
		
		Docente docente = null;
		
		Connection conn = DBManager.getConnection();
		
		String sqlquery = "SELECT Nome,Cognome,NElaborati FROM Docente WHERE CodiceInsegnamento=?";
		
		try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
		{
			
			stmt.setInt(1, codiceinsegnamento);

			try( ResultSet result = stmt.executeQuery(); )  
			{
				while (result.next()) {
	        	
					String nome =result.getString(1);
					String cognome =result.getString(2);
					int nelaborati=result.getInt(3)
;					
					docente=new Docente(nome,cognome,codiceinsegnamento,nelaborati);
				}
			}
		}
		catch(SQLException e) {

			throw new DAOException("Errore SELECT Docente");
		}
		
		return docente;
	}

public static ArrayList<Docente> readAll() throws DAOException {
	
	ArrayList<Docente> docentilist = new ArrayList<Docente>();
	
	Connection conn = DBManager.getConnection();
	
	String sqlquery = "SELECT Nome,Cognome,CodiceInsegnamento FROM Docente";
	
	try ( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
	{

		try( ResultSet result = stmt.executeQuery(); )
		{
			while (result.next()) {
        	
				String nome= result.getString(1);
				String cognome = result.getString(2);
				int codiceinsegnamento = result.getInt(3);
				int nelaborati=result.getInt(3);					
				
				Docente docente=new Docente(nome,cognome,codiceinsegnamento,nelaborati);

				docentilist.add(docente);
			}
		}
	}
	catch(SQLException e) {

		throw new DAOException("Errore SELECT Docente");
	}
	
	return docentilist;
}
public static void update(Docente docente) throws DAOException {
	
	Connection conn = DBManager.getConnection();
	
	String sqlquery=
			"SET @IncrementValue = 1;\n" + 
			"UPDATE Docente SET Nome=?, Cognome=?, NElaborati = NElaborati + @IncrementValue WHERE Codiceinsegnamento=?;";
	

	try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
	{
		stmt.setString(1,docente.getnome().toString());
		stmt.setString(2, docente.getcognome().toString());
		stmt.setInt(3, docente.getcodiceInsegnamento());
		
		stmt.executeUpdate();
	}
	catch(SQLException e) {

		throw new DAOException("Errore UPDATE Docente");
	}
}

public static void delete(Docente docente) throws DAOException {
	
	int codiceinsegnamento = docente.getcodiceInsegnamento();
	
	Connection conn = DBManager.getConnection();
	
	String sqlquery = "DELETE FROM Docente WHERE CodiceInsegnamento=?;";
	
	try( PreparedStatement stmt = conn.prepareStatement(sqlquery); )
	{
		stmt.setInt(1, codiceinsegnamento);
		
		stmt.executeUpdate();
	}
	catch(SQLException e) {

		throw new DAOException("Errore DELETE Docente");
	}
}

}
